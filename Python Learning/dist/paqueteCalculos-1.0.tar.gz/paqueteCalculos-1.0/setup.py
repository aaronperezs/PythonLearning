from setuptools import setup
import distutils

setup(

    name="paqueteCalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Aaron",
    author_email="aaronperezmail@gmail.com",
    url="www.google.es",
    packages=["calculos","calculos.redondeo_potencia"]


)